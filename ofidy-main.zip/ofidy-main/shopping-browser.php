<?php include "components/head.inc.php"; ?>
  </head>

  <body>
    <nav class="navbar navbar-light bg-success text-white fixed-top shadow py-3">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center w-100">
                <a class="text-white make-bold text-uppercase lt-2" href="index.php"><span class="d-inline-block d-xl-none d-lg-none"><i data-feather="home"></i></span> <span class="d-none d-xl-inline-block d-lg-inline-block"><i data-feather="chevron-left"></i> Back Home</span></a>
                <a class="text-white make-bold text-uppercase lt-2" href="browse.php"><i data-feather="list"></i> <span class="d-none d-xl-inline-block d-lg-inline-block">Browse Stores</span></a>
            </div>
        </div>
    </nav>
    <div class="split-grid">
        <div class="split-1 bg-danger use-image-2" style="background-image:url(images/bg-1.jpg)"></div>
        <div class="split-2 bg-white">
            <div class="content-split-holder  d-flex justify-content-center align-items-center h-100 flex-column">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 mx-auto">
                            <div class="content-split text-center">
                                <img src="images/logo.png" class="img-fluid mb-3" width="200" />
                                <h2 class="make-bold">Buy From Other Online Stores Using the Ofidy Shopping Browser</h2>
                                <p>You can securely buy items from online stores in Canada, USA, UK, Europe, Nigeria, UAE and China (English based websites).</p>
                                <ul class="list-unstyled shopping-browser-how">
                                    <li>Type the Store URL in the Ofidy Shopping Browser.</li>

                                    <li>Use the Ofidy Shopping Browser to add items to your cart from several websites in different countries and/or different currencies.</li>

                                    <li>Checkout in one cart and in one currency.</li>

                                    <li><a href="">Watch short video on how to use the Ofidy Shopping Browser</a></li>

                                    <li>Download Ofidy Shopping Browser for Android</li>
                                </ul>
                                <div class="banner-content">
                                    <h3 class="make-bold mb-2">Download the App.</h3>
                                    <p>Available on Android, iOS and Chrome Extension</p>
                                    <div class="row">
                                        <div class="col-lg-8 mx-auto">
                                            <div class="row">
                                                <div class="col-lg-4 mb-3">
                                                    <a href=""><img src="images/google-play.svg" class="img-fluid  mb-2"></a>
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <a href=""><img src="images/app-store-btn.svg" class="img-fluid  mb-2"></a>
                                                </div>
                                                <div class="col-lg-4 mb-3">
                                                    <a href=""><img src="images/chrome.png" class="img-fluid  mb-2"></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include "components/javascript.inc.php"; ?>
  </body>
</html>
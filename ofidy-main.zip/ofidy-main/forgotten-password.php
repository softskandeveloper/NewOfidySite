<?php include "components/head.inc.php"; ?>
  </head>
  <body>
    <?php include "components/navbar.inc.php"; ?>

    <div class="main-content">
        <div class="items-sect mt-50 bg-light">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 mx-auto">
                        <div class="login-sect py-5">
                            <div class="card">
                                <div class="card-body">
                                    <div class="text-center mb-4">
                                        <h2 class="make-bold">Forgotten Password</h2>
                                    </div>
                                    <form action="reset-password.php" method="post">
                                        <div class="form-group">
                                            <label>Email Address</label>
                                            <input type="text" class="form-control is-valid" />
                                             <div class="valid-feedback">
                                                Looks good
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <button class="btn btn-success text-white lt-2 text-uppercase btn-block">Reset Password</button>
                                        </div>
                                    </form>
                                    <div class="text-center">
                                        <p class="mb-1">Back to Login <a href="login.php" class="text-success">Login</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-lg-7">
                        <img src="images/vector-1.png" class="img-fluid d-none d-xl-block d-lg-block" />
                    </div> -->
                </div>
            </div>
        </div>
    </div>
    <?php include "components/footer.inc.php"; ?>
    <?php include "components/javascript.inc.php"; ?>
  </body>
</html>
<?php include "components/head.inc.php"; ?>
  </head>
  <body>
    <?php include "components/navbar.inc.php"; ?>
     <?php include "components/slider.php"; ?>

    <div class="main-content">
        <div class="order-sect pt-5">
            <div class="cart-holder">
                <div class="container">
                <h1 class="make-bold">My Orders</h1>
                <div class="row">
                    <div class="col-lg-12 p-5 bg-white rounded shadow-sm mb-5">

                    <!-- Shopping cart table -->
                    <div class="table-responsive no-wrap">
                        <table class="table">
                        <thead>
                            <tr>
                                <th scope="col" class="border-0 bg-light">
                                    <div class="p-2 px-3 text-uppercase">Product</div>
                                </th>
                                <th scope="col" class="border-0 bg-light">
                                    <div class="py-2 text-uppercase">Price</div>
                                </th>
                                <th scope="col" class="border-0 bg-light">
                                    <div class="py-2 text-uppercase">Quantity</div>
                                </th>
                                <th scope="col" class="border-0 bg-light">
                                    <div class="py-2 text-uppercase">Current Status</div>
                                </th>
                                <th scope="col" class="border-0 bg-light">
                                    <div class="py-2 text-uppercase">Delivery Location</div>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                            <th scope="row" class="border-0">
                                <div class="p-2">
                                    <div class="media align-items-center">
                                        <div class="thumb-sect mr-3 rounded shadow-sm">
                                            <img src="images/product-3.jpg" class="h-100 w-100 obj-cover" alt="...">
                                        </div>
                                        <div class="media-body">
                                            <h6 class="mt-0 mb-0 text-dark">Pepperidge Farm® Mint Chocolate Cookies</h6>
                                            <span class="text-muted">Shipped from UK.</span>
                                        </div>
                                    </div>
                                </div>
                            </th>
                            <td class="border-0 align-middle"><strong>$79.00</strong></td>
                            <td class="border-0 align-middle"><strong>3</strong></td>
                            <td class="border-0 align-middle"><strong>22 Feb 2021 10: 54am</strong><p class="text-muted">Item has been shipped</p></td>
                            <td class="align-middle">39 Sura mogaji street, Ilupeju, Lagos</td>
                            </tr>
                            <tr>
                            <th scope="row">
                                <div class="p-2">
                                    <div class="media align-items-center">
                                        <div class="thumb-sect mr-3 rounded shadow-sm">
                                            <img src="images/product-1.jpg" class="h-100 w-100 obj-cover" alt="...">
                                        </div>
                                        <div class="media-body">
                                            <h6 class="mt-0 mb-0 text-dark">Oreo Thins Chocolate Sandwich Cookies, Original Flavor, 1 Resealable Pack</h6>
                                            <span class="text-muted">Shipped from Uk</span>
                                        </div>
                                    </div>
                                </div>
                            </th>
                                <td class="align-middle"><strong>$79.00</strong></td>
                                <td class="align-middle"><strong>3</strong></td>
                                <td class="align-middle"><strong>22 Feb 2021 10: 54am</strong><p class="text-muted">Item has been shipped</p>
                                <td class="align-middle">39 Sura mogaji street, Ilupeju, Lagos</td>
                            </td>
                            </tr>
                            <tr>
                            <th scope="row">
                                <div class="p-2">
                                    <div class="media align-items-center">
                                        <div class="thumb-sect mr-3 rounded shadow-sm">
                                            <img src="images/product-2.jpg" class="h-100 w-100 obj-cover" alt="...">
                                        </div>
                                        <div class="media-body">
                                            <h6 class="mt-0 mb-0 text-dark">Oreo Golden Sandwich Cookies, Vanilla Flavor, 1 Resealable Family Size Pack</h6>
                                            <span class="text-muted">Shipped from UK</span>
                                        </div>
                                    </div>
                                </div>
                                <td class="align-middle"><strong>$79.00</strong></td>
                                <td class="align-middle"><strong>3</strong></td>
                                <td class="align-middle"><strong>22 Feb 2021 10: 54am</strong><p class="text-muted">Item has been shipped</p>
                                </td>
                                <td class="align-middle">39 Sura mogaji street, Ilupeju, Lagos</td>
                            </tr>
                        </tbody>
                        </table>
                    </div>
                    <!-- End -->
                    </div>
                </div>

                </div>
            </div>
        </div>
    </div>
    <?php include "components/footer.inc.php"; ?>
    <?php include "components/javascript.inc.php"; ?>
  </body>
</html>
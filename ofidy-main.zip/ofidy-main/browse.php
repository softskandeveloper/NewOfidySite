<?php include "components/head.inc.php"; ?>
  </head>
  <body>
    <?php include "components/navbar.inc.php"; ?>

    <div class="main-content">
        <?php include "components/slider.php"; ?>
        <div class="items-sect h-100 py-50">
            <div class="container-fluid">
                <div class="store-list">
                    <div class="heading-store">
                        <h2 class="make-bold">Browse different stores</h2>
                        <p class="text-muted">Get affordable groceries, home appliances from any of the stores listed</p>
                    </div>
                    <div class="row">
                        <?php include "components/items-2.inc.php"; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include "components/footer.inc.php"; ?>
    <?php include "components/javascript.inc.php"; ?>
  </body>
</html>
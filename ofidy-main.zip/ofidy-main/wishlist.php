<?php include "components/head.inc.php"; ?>
  </head>
  <body>
    <?php include "components/navbar.inc.php"; ?>
    <?php include "components/slider.php"; ?>
    <div class="main-content">
        <div class="product-list-view">
            <div class="product-list-sect pt-5">
                <div class="container-fluid">
                    <h1 class="make-bold">My Wishlist</h1>
                    <hr/>
                    <div class="row">
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-1.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N5,000</h6>
                                        <p class="card-text text-muted item-name">Oreo Mini Chocolate Sandwich Cookies, Original Flavor, 1 Resealable Snak-Sak</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-2.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N10,000</h6>
                                        <p class="card-text text-muted item-name">Lenny & Larry's Lenny & Larry's The Complete Cookie®, Chocolate Chip, 4oz - Plant Based Protein Cookies, Vegan and Non-GMO</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-3.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N20,000</h6>
                                        <p class="card-text text-muted item-name">Chips Ahoy! Mini Chocolate Chip Cookies - Go Pak</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-4.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N 30,000</h6>
                                        <p class="card-text text-muted item-name">Rice Krispies Treats Crispy Marshmallow Squares Original with M&M'S Minis</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-5.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N40,000</h6>
                                        <p class="card-text text-muted item-name">BelVita Breakfast Biscuits, Blueberry Flavor</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-6.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N4,000</h6>
                                        <p class="card-text text-muted item-name">Pepperidge Farm® Mint Chocolate Cookies</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-1.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N5,000</h6>
                                        <p class="card-text text-muted item-name">Oreo Mini Chocolate Sandwich Cookies, Original Flavor, 1 Resealable Snak-Sak</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-2.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N10,000</h6>
                                        <p class="card-text text-muted item-name">Lenny & Larry's Lenny & Larry's The Complete Cookie®, Chocolate Chip, 4oz - Plant Based Protein Cookies, Vegan and Non-GMO</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include "components/footer.inc.php"; ?>
    <?php include "components/javascript.inc.php"; ?>
  </body>
</html>
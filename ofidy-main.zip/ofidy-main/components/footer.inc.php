<footer class="app-footer py-50 bg-dark text-white">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3">
                <div class="text-center">
                    <img src="images/logo-transparent.png" class="img-fluid mb-4" width="300" />
                </div>
                <p>Ofidy.com is a Global online shopping mall designed to assist buyers purchase products from different countries around the world and get it delivered to them.</p>
            </div>
            <div class="col-lg-3">
                <h4 class="make-bold mb-4">Quick Links</h4>
                <ul class="list-unstyled text-white">
                    <li><a href="">Download Android App</a></li>
                    <li><a href="">Download Apple App</a></li>
                    <li><a href="">Refund Policy</a></li>
                    <li><a href="">Terms and Condition</a></li>
                    <li><a href="">Pricing</a></li>
                </ul>
            </div>
            <div class="col-lg-3">
                <h4 class="make-bold mb-4">Resources</h4>
                <ul class="list-unstyled text-white">
                    <li><a href="">Download Android App</a></li>
                    <li><a href="">Download Apple App</a></li>
                    <li><a href="">Refund Policy</a></li>
                    <li><a href="">Terms and Condition</a></li>
                    <li><a href="">Pricing</a></li>
                </ul>
            </div>
            <div class="col-lg-3">
                <h4 class="make-bold mb-4">Contact Us</h4>
                <p>Ofidy Project Team, SoftSkan LLC,5022 Campbell Boulevard, Suite E, Nottingham, MD 21236, USA</p>
                <p><a href="mailto:support@ofidy.com">support@ofidy.com</a></p>
                <p>+1 410 929 3978</p>
            </div>
        </div>
        <div class="row align-item-center mt-5">
            <div class="col-lg-10 mb-3">
                &copy; 2021 Designed and developed by SoftSkan
            </div>
            <div class="col-lg-2 mb-3">
               <ul class="list-unstyled d-flex justify-content-between align-items-center">
                    <li><a href=""><i class="fab fa-facebook fa-lg"></i></a></li>
                    <li><a href=""><i class="fab fa-twitter fa-lg"></i></a></li>
                    <li><a href=""><i class="fab fa-instagram fa-lg"></i></a></li>
               </ul>
            </div>
        </div>
    </div>
</footer>
    <div class="col-lg-3 mb-4">
        <a href="products.php" class="rmv-decoration">
            <div class="card border-rad-12 box-shadow items-card border-0 h-100">
                <div class="card-body">
                    <div class="media align-items-center">
                        <div class="thumb-sect mr-3">
                            <img src="images/brand-1.png" class="h-100 w-100 obj-cover" alt="...">
                        </div>
                        <div class="media-body">
                            <h5 class="mt-0 make-bold mb-0 text-dark">Costco</h5>
                            <span class="text-muted">Groceries - Home Electronic</span>
                        </div>
                        <div class="status-incoming">
                            <span class="badge badge-warning text-white">New Store<span>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-lg-3 mb-4">
        <a href="products.php" class="rmv-decoration">
            <div class="card border-rad-12 box-shadow items-card border-0 h-100">
                <div class="card-body">
                    <div class="media align-items-center">
                        <div class="thumb-sect mr-3">
                            <img src="images/brand-2.png" class="h-100 w-100 obj-cover" alt="...">
                        </div>
                        <div class="media-body">
                            <h5 class="mt-0 make-bold mb-0 text-dark">CVS Pharmacy</h5>
                            <span class="text-muted">Pharmaceutical</span>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-lg-3 mb-4">
        <a href="products.php" class="rmv-decoration">
            <div class="card border-rad-12 box-shadow items-card border-0 h-100">
                <div class="card-body">
                    <div class="media align-items-center">
                        <div class="thumb-sect mr-3">
                            <img src="images/brand-3.png" class="h-100 w-100 obj-cover" alt="...">
                        </div>
                        <div class="media-body">
                            <h5 class="mt-0 make-bold mb-0 text-dark">Target</h5>
                            <span class="text-muted">Groceries - Home Electronics</span>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-lg-3 mb-4">
        <a href="products.php" class="rmv-decoration">
            <div class="card border-rad-12 box-shadow items-card border-0 h-100">
                <div class="card-body">
                    <div class="media align-items-center">
                        <div class="thumb-sect mr-3">
                            <img src="images/brand-4.png" class="h-100 w-100 obj-cover" alt="...">
                        </div>
                        <div class="media-body">
                            <h5 class="mt-0 make-bold mb-0 text-dark">Walmart</h5>
                            <span class="text-muted">Home Electronics - Groceries</span>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-lg-3 mb-4">
        <a href="products.php" class="rmv-decoration">
            <div class="card border-rad-12 box-shadow items-card border-0 h-100">
                <div class="card-body">
                    <div class="media align-items-center">
                        <div class="thumb-sect mr-3">
                            <img src="images/brand-5.png" class="h-100 w-100 obj-cover" alt="...">
                        </div>
                        <div class="media-body">
                            <h5 class="mt-0 make-bold mb-0 text-dark">Tesco</h5>
                            <span class="text-muted">Groceries - Home Electronic</span>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-lg-3 mb-4">
        <a href="products.php" class="rmv-decoration">
            <div class="card border-rad-12 box-shadow items-card border-0 h-100">
                <div class="card-body">
                    <div class="media align-items-center">
                        <div class="thumb-sect mr-3">
                            <img src="images/brand-1.png" class="h-100 w-100 obj-cover" alt="...">
                        </div>
                        <div class="media-body">
                            <h5 class="mt-0 make-bold mb-0 text-dark">Costco</h5>
                            <span class="text-muted">Groceries - Home Electronic</span>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-lg-3 mb-4">
        <a href="products.php" class="rmv-decoration">
            <div class="card border-rad-12 box-shadow items-card border-0 h-100">
                <div class="card-body">
                    <div class="media align-items-center">
                        <div class="thumb-sect mr-3">
                            <img src="images/brand-2.png" class="h-100 w-100 obj-cover" alt="...">
                        </div>
                        <div class="media-body">
                            <h5 class="mt-0 make-bold mb-0 text-dark">CVS Pharmacy</h5>
                            <span class="text-muted">Fashion</span>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-lg-3 mb-4">
        <a href="products.php" class="rmv-decoration">
            <div class="card border-rad-12 box-shadow items-card border-0 h-100">
                <div class="card-body">
                    <div class="media align-items-center">
                        <div class="thumb-sect mr-3">
                            <img src="images/brand-5.png" class="h-100 w-100 obj-cover" alt="...">
                        </div>
                        <div class="media-body">
                            <h5 class="mt-0 make-bold mb-0 text-dark">Tesco</h5>
                            <span class="text-muted">Fashion</span>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
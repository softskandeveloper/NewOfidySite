<?php include "components/head.inc.php"; ?>
  </head>
  <body>
    <?php include "components/navbar.inc.php"; ?>
     <?php include "components/slider.php"; ?>

    <div class="main-content">
        <div class="account-sect bg-light pt-5">
            <div class="cart-holder">
                <div class="container">
                <h1 class="make-bold">Account Information</h1>
                <hr/>
                <div class="row">
                    <div class="col-lg-8 rounded mb-5">
                        <div class="account-info">
                            <div class="card card-body">
                                <form>
                                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label>First Name</label>
                                            <input type="text" class="form-control" placeholder="First Name">
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label>Last Name</label>
                                            <input type="text" class="form-control" placeholder="Last Name">
                                        </div>
                                         <div class="form-group col-md-6">
                                            <label>Middle Name</label>
                                            <input type="text" class="form-control" placeholder="Last Name">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Address</label>
                                        <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
                                    </div>
                                    <div class="form-group">
                                        <label>Address 2</label>
                                        <input type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
                                    </div>


                                    <button type="submit" class="btn btn-main text-white">Save Changes</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                </div>
            </div>
        </div>
    </div>
    <?php include "components/footer.inc.php"; ?>
    <?php include "components/javascript.inc.php"; ?>
  </body>
</html>
<?php include "components/head.inc.php"; ?>
  </head>
  <body>
    <?php include "components/navbar.inc.php"; ?>

    <div class="main-content">
        <div class="product-list-view">
            <div class="header-sect pos-relative text-white use-image pt-4 pb-5" style="background-image: url(images/banner.jpg)">
                <div class="overlay"></div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 mx-auto mb-5">
                            <div class="thumb-sect-2 mx-auto">
                                <img src="images/brand-3.png" class="h-100 w-100 obj-cover" alt="...">
                            </div>
                            <div class="text-center mt-4">
                                <p class="mb-0">Global shopping made easy</p>
                                <h4 class="make-bold">Everything you buy from this page is from Target Uk</h4>
                            </div>
                            <div class="mt-5">
                                <form>
                                    <div class="form-group">
                                        <label>Search for Items</label>
                                        <input type="text" class="form-control form-control-lg" placeholder="Search for items..." />
                                    </div>
                                    <div class="form-group">
                                        <button class="btn btn-main btn-block text-uppercase text-white make-bold lt-2">Search</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="product-list-sect pt-5">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-1.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N5,000</h6>
                                        <p class="card-text text-muted item-name">Oreo Mini Chocolate Sandwich Cookies, Original Flavor, 1 Resealable Snak-Sak</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-2.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N10,000</h6>
                                        <p class="card-text text-muted item-name">Lenny & Larry's Lenny & Larry's The Complete Cookie®, Chocolate Chip, 4oz - Plant Based Protein Cookies, Vegan and Non-GMO</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-3.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N20,000</h6>
                                        <p class="card-text text-muted item-name">Chips Ahoy! Mini Chocolate Chip Cookies - Go Pak</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-4.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N 30,000</h6>
                                        <p class="card-text text-muted item-name">Rice Krispies Treats Crispy Marshmallow Squares Original with M&M'S Minis</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-5.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N40,000</h6>
                                        <p class="card-text text-muted item-name">BelVita Breakfast Biscuits, Blueberry Flavor</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-6.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N4,000</h6>
                                        <p class="card-text text-muted item-name">Pepperidge Farm® Mint Chocolate Cookies</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-1.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N5,000</h6>
                                        <p class="card-text text-muted item-name">Oreo Mini Chocolate Sandwich Cookies, Original Flavor, 1 Resealable Snak-Sak</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-2.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N10,000</h6>
                                        <p class="card-text text-muted item-name">Lenny & Larry's Lenny & Larry's The Complete Cookie®, Chocolate Chip, 4oz - Plant Based Protein Cookies, Vegan and Non-GMO</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-3.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N20,000</h6>
                                        <p class="card-text text-muted item-name">Chips Ahoy! Mini Chocolate Chip Cookies - Go Pak</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-4.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N 30,000</h6>
                                        <p class="card-text text-muted item-name">Rice Krispies Treats Crispy Marshmallow Squares Original with M&M'S Minis</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-5.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N40,000</h6>
                                        <p class="card-text text-muted item-name">BelVita Breakfast Biscuits, Blueberry Flavor</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-6.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N4,000</h6>
                                        <p class="card-text text-muted item-name">Pepperidge Farm® Mint Chocolate Cookies</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-1.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N5,000</h6>
                                        <p class="card-text text-muted item-name">Oreo Mini Chocolate Sandwich Cookies, Original Flavor, 1 Resealable Snak-Sak</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-2.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N10,000</h6>
                                        <p class="card-text text-muted item-name">Lenny & Larry's Lenny & Larry's The Complete Cookie®, Chocolate Chip, 4oz - Plant Based Protein Cookies, Vegan and Non-GMO</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-3.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N20,000</h6>
                                        <p class="card-text text-muted item-name">Chips Ahoy! Mini Chocolate Chip Cookies - Go Pak</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-4.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N 30,000</h6>
                                        <p class="card-text text-muted item-name">Rice Krispies Treats Crispy Marshmallow Squares Original with M&M'S Minis</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-5.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N40,000</h6>
                                        <p class="card-text text-muted item-name">BelVita Breakfast Biscuits, Blueberry Flavor</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-6.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N4,000</h6>
                                        <p class="card-text text-muted item-name">Pepperidge Farm® Mint Chocolate Cookies</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-1.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N5,000</h6>
                                        <p class="card-text text-muted item-name">Oreo Mini Chocolate Sandwich Cookies, Original Flavor, 1 Resealable Snak-Sak</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-2.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N10,000</h6>
                                        <p class="card-text text-muted item-name">Lenny & Larry's Lenny & Larry's The Complete Cookie®, Chocolate Chip, 4oz - Plant Based Protein Cookies, Vegan and Non-GMO</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-3.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N20,000</h6>
                                        <p class="card-text text-muted item-name">Chips Ahoy! Mini Chocolate Chip Cookies - Go Pak</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-4.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N 30,000</h6>
                                        <p class="card-text text-muted item-name">Rice Krispies Treats Crispy Marshmallow Squares Original with M&M'S Minis</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-5.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N40,000</h6>
                                        <p class="card-text text-muted item-name">BelVita Breakfast Biscuits, Blueberry Flavor</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-2 col-6 mb-3">
                            <a href="product.php" class="rmv-decoration">
                                <div class="card text-dark h-100 thumbnail-card border-0">
                                    <div class="thumbnail-holder-3">
                                        <img src="images/product-6.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                    </div>
                                    <div class="card-body d-flex flex-column align-items-start">
                                        <h6 class="card-title make-bold flex-grow-1">N4,000</h6>
                                        <p class="card-text text-muted item-name">Pepperidge Farm® Mint Chocolate Cookies</p>
                                        <badge class="badge badge-info">Shipped From Uk</badge>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div aria-label="Page navigation">
                        <ul class="pagination justify-content-center">
                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item"><a class="page-link" href="#">4</a></li>
                            <li class="page-item"><a class="page-link" href="#">5</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include "components/footer.inc.php"; ?>
    <?php include "components/javascript.inc.php"; ?>
  </body>
</html>
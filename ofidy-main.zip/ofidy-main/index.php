<?php include "components/head.inc.php"; ?>
  </head>
  <body>
    <?php include "components/navbar.inc.php"; ?>

    <div class="main-content">
        <?php include "components/slider.php"; ?>

        <div class="items-sect h-100 py-50">
            <div class="container-fluid">
                <div class="text-center">
                    <h2 class="make-bold">Suggested Stores</h2>
                    <p class="text-muted">Some set of suggested stores that you from Walmart, Target, or CVS</p>
                </div>
                <div class="row info-list-sect-2">
                   <?php include "components/items.inc.php"; ?>
                </div>
                <!--<div class="text-center">
                    <a href="" class="btn btn-success text-white lt-2 text-uppercase make-bold">View all stores</a>
                </div>-->
            </div>
        </div>

        <div class="product-ads-sect mb-5">
            <div class="container-fluid">
                <div class="row overflow-x-scroll flex-nowrap no-scroll-bar">
                    <div class="col-lg-5 col-11 mb-3">
                        <a href="">
                            <div class="thumbnail-holder-5">
                                <img src="images/ad2.jpg" class="card-img-top obj-contain h-100 w-100 bord-rad-20" alt="...">
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-5 col-11 mb-3">
                        <a href="">
                            <div class="thumbnail-holder-5">
                                <img src="images/ad3.jpg" class="card-img-top obj-contain h-100 w-100 bord-rad-20" alt="...">
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-5 col-11 mb-3">
                        <a href="">
                            <div class="thumbnail-holder-5">
                                <img src="images/ad4.jpg" class="card-img-top obj-contain h-100 w-100 bord-rad-20" alt="...">
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-5 col-11 mb-3">
                        <a href="">
                            <div class="thumbnail-holder-5">
                                <img src="images/ad5.jpg" class="card-img-top obj-contain h-100 w-100 bord-rad-20" alt="...">
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

         <div class="info-list-sect py-50">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-3 mb-3">
                        <a href="" class="rmv-decoration">
                            <div class="card h-100 thumbnail-card border-0">
                                <!-- <div class="thumbnail-holder-2">
                                    <img src="images/img-1.jpg" class="card-img-top obj-cover h-100 w-100" alt="...">
                                </div> -->
                                <div class="card-body d-flex flex-column align-items-start">
                                    <h3 class="card-title make-medium flex-grow-1 make-bold">Shopping Made Quick & Easy All the things you want, everywhere you shop</h3>
                                    <p class="card-text">We know you have your go-to products from your favorite stores. That’s why we deliver from local and national retailers people love – like Walmart, Target, Petco, or CVS.</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-3 mb-3">
                        <a href="" class="rmv-decoration">
                            <div class="card h-100 thumbnail-card border-0">
                                <!-- <div class="thumbnail-holder-2">
                                    <img src="images/img-2.jpg" class="card-img-top obj-cover h-100 w-100" alt="...">
                                </div> -->
                                <div class="card-body d-flex flex-column align-items-start">
                                    <h3 class="card-title make-bold flex-grow-1">Get instant updates on every order. Up-to-the-minute updates on every process</h3>
                                    <p class="card-text">Get up-to-the-minute updates with every order. Forget to add something to your list? If we’re still in the aisle, you can still get it delivered.</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-3 mb-3">
                        <a href="" class="rmv-decoration">
                            <div class="card h-100 thumbnail-card border-0">
                                <!-- <div class="thumbnail-holder-2">
                                    <img src="images/img-2.jpg" class="card-img-top obj-cover h-100 w-100" alt="...">
                                </div> -->
                                <div class="card-body d-flex flex-column align-items-start">
                                    <h3 class="card-title make-bold flex-grow-1">Download Our Shopping Browser now</h3>
                                    <p class="card-text">Life is easy on Mobile. Visit the Google Play / Apple App Store to download the Ofidy shopping browser and shop on the go. Install the Ofidy shopping Browser for Android / iOS.</p>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-3 mb-3">
                        <a href="" class="rmv-decoration">
                            <div class="card h-100 thumbnail-card border-0">
                                <!-- <div class="thumbnail-holder-2">
                                    <img src="images/img-2.jpg" class="card-img-top obj-cover h-100 w-100" alt="...">
                                </div> -->
                                <div class="card-body d-flex flex-column align-items-start">
                                    <h3 class="card-title make-bold flex-grow-1">Suggested list of stores</h3>
                                    <p class="card-text">We have listed a couple of thousands of stores in the the USA, UK, other EU countries and the UAE that you can shop from. While in the Ofidy Shopping Browser the menu shows you shops that sells items under your chosen category.</p>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div id="grad" class="banner-sect d-flex justify-content-center align-items-center py-50">
            <div class="container">
                <div class="row align-items-center">
                    <!-- <div class="col-lg-5">
                       <img src="images/phone-view-2.png" class="img-fluid phone-view-1">
                    </div> -->
                    <div class="col-lg-7 mx-auto text-center z-index text-center-sm">
                        <div class="banner-content text-white">
                            <h1 class="make-bold mb-2">Download the App.</h1>
                            <p>Available on Android, iOS and Chrome Extension</p>
                            <div class="row">
                               <div class="col-lg-10 mx-auto">
                                    <div class="row">
                                        <div class="col-lg-4 mb-3">
                                            <a href=""><img src="images/google-play.svg" class="img-fluid  mb-2"></a>
                                        </div>
                                        <div class="col-lg-4 mb-3">
                                             <a href=""><img src="images/app-store-btn.svg" class="img-fluid  mb-2"></a>
                                        </div>
                                        <div class="col-lg-4 mb-3">
                                             <a href=""><img src="images/chrome.png" class="img-fluid  mb-2"></a>
                                        </div>
                                    </div>
                               </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include "components/footer.inc.php"; ?>
    <?php include "components/javascript.inc.php"; ?>
  </body>
</html>
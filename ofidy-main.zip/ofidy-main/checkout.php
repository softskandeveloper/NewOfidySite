<?php include "components/head.inc.php"; ?>
  </head>
  <body>
    <?php include "components/navbar.inc.php"; ?>

    <div class="main-content">
        <div class="checkout-sect py-5">
            <div class="checkout-holder">
                <div class="container">
                    <h1 class="make-bold">Checkout</h1>
                    <div class="row">
                        <div class="col-lg-8 mb-3">
                            <div class="checkout-container">
                                <div class="accordion accordion-container" id="accordionCheckout">
                                    <div class="card mb-3">
                                        <div class="card-header bg-white" id="headingOne">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                <span class="text-dark">Billing Address</span>
                                            </button>
                                        </h2>
                                        </div>

                                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionCheckout">
                                        <div class="card-body">
                                            <div class="checkout-content">
                                                <p>Select a billing address or enter an address</p>
                                                <div class="form-group">
                                                    <select class="form-control">
                                                        <option>
                                                            Address 1
                                                        </option>
                                                        <option>
                                                            Address 2
                                                        </option>
                                                    </select>
                                                </div>
                                                <div class="form-row">
                                                    <div class="form-group col-lg-6 mb-3">
                                                        <button class="btn btn-secondary btn-block text-white" data-toggle="modal" data-target="#addressModalCenter">Enter an address</button>
                                                    </div>
                                                    <div class="form-group col-lg-6 mb-3">
                                                        <button type="button" class="btn btn-main btn-block collapsed text-white" data-toggle="collapse" data-parent="#accordionCheckout" data-target="#collapseTwo">Next</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="card mb-3">
                                        <div class="card-header bg-white" id="headingTwo">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                <span class="text-dark">Select delivery options</span>
                                            </button>
                                        </h2>
                                        </div>
                                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionCheckout">
                                            <div class="card-body">
                                                <div class="mb-3">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="addressRadios" id="addressRadios1" value="option1" checked>
                                                        <label class="form-check-label" for="addressRadios1">
                                                            Deliver to my address
                                                        </label>
                                                        </div>
                                                        <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="addressRadios" id="addressRadios2" value="option2">
                                                        <label class="form-check-label" for="addressRadios2">
                                                            Deliver to my Ofidy pickup location
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="form-row">
                                                    <div class="form-group col-lg-6 mb-3">
                                                        <button class="btn btn-info btn-block text-white" data-toggle="collapse" data-parent="#accordionCheckout" data-target="#collapseOne">Previous</button>
                                                    </div>
                                                    <div class="form-group col-lg-6 mb-3">
                                                        <button type="button" class="btn btn-main btn-block collapsed text-white" data-toggle="collapse" data-parent="#accordionCheckout" data-target="#collapseThree">Next</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card mb-3">
                                        <div class="card-header bg-white" id="headingThree">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                <span class="text-dark">Shipping Information</span>
                                            </button>
                                        </h2>
                                        </div>
                                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionCheckout">
                                        <div class="card-body">
                                            <div class="checkout-content">
                                                <p>Select a shipping address or enter an address</p>
                                                <div class="form-group">
                                                    <select class="form-control">
                                                        <option>
                                                            Address 1
                                                        </option>
                                                        <option>
                                                            Address 2
                                                        </option>
                                                    </select>
                                                </div>
                                                <div class="form-row">
                                                    <div class="form-group col-lg-4 mb-3">
                                                        <button class="btn btn-secondary btn-block text-white">Enter an address</button>
                                                    </div>
                                                    <div class="form-group col-lg-4 mb-3">
                                                        <button type="button" class="btn btn-info btn-block collapsed text-white" data-toggle="collapse" data-parent="#accordionCheckout" data-target="#collapseTwo">Previous</button>
                                                    </div>
                                                    <div class="form-group col-lg-4 mb-3">
                                                        <button type="button" class="btn btn-main btn-block collapsed text-white" data-toggle="collapse" data-parent="#accordionCheckout" data-target="#collapseFour">Next</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="card mb-3">
                                        <div class="card-header bg-white" id="headingFour">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                                <span class="text-dark">Shipping Method</span>
                                            </button>
                                        </h2>
                                        </div>
                                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionCheckout">
                                        <div class="card-body">
                                            <div class="checkout-content">
                                                <div class="mb-3">
                                                    <p>Select a shipping option :Includes: Shipping Cost and Other Charges</p>
                                                    <div class="form-group">
                                                        <select class="form-control">
                                                            <option>
                                                                You must select shipping address before selecting shipping options
                                                            </option>
                                                            <option>
                                                                Address 2
                                                            </option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label>Any comments/notes for shipping & delivery:</label>
                                                    <textarea class="form-control" rows="4"></textarea>
                                                </div>
                                                <div class="form-row">
                                                    <div class="form-group col-lg-6 mb-3">
                                                        <button type="button" class="btn btn-info btn-block collapsed text-white" data-toggle="collapse" data-parent="#accordionCheckout" data-target="#collapseThree">Previous</button>
                                                    </div>
                                                    <div class="form-group col-lg-6 mb-3">
                                                        <button type="button" class="btn btn-main btn-block collapsed text-white" data-toggle="collapse" data-parent="#accordionCheckout" data-target="#collapseFive">Next</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="card mb-3">
                                        <div class="card-header bg-white" id="headingFive">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                                <span class="text-dark">Payment Method</span>
                                            </button>
                                        </h2>
                                        </div>
                                        <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionCheckout">
                                        <div class="card-body">
                                            <div class="checkout-content">
                                                <div class="mb-3">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="paymentRadios" id="paymentRadios1" value="option1" checked>
                                                        <label class="form-check-label" for="paymentRadios1">
                                                            Bank Transfer
                                                        </label>
                                                        </div>
                                                        <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="paymentRadios" id="paymentRadios2" value="option2">
                                                        <label class="form-check-label" for="paymentRadios2">
                                                            Card Payment (RAVE)
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="form-row">
                                                    <div class="form-group col-lg-6 mb-3">
                                                        <button type="button" class="btn btn-info btn-block collapsed text-white" data-toggle="collapse" data-parent="#accordionCheckout" data-target="#collapseFour">Previous</button>
                                                    </div>
                                                    <div class="form-group col-lg-6 mb-3">
                                                        <button type="button" class="btn btn-main btn-block collapsed text-white" data-toggle="collapse" data-parent="#accordionCheckout" data-target="#collapseSix">Next</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="card mb-3">
                                        <div class="card-header bg-white" id="headingSix">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                                <span class="text-dark">Summary</span>
                                            </button>
                                        </h2>
                                        </div>
                                        <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordionCheckout">
                                        <div class="card-body">
                                            <div class="checkout-content">

                                                 <!-- Shopping cart table -->
                                                <div class="table-responsive mb-3">
                                                    <table class="table no-wrap table-striped table-hover">
                                                        <thead>
                                                            <tr>
                                                                <th scope="col" class="bg-light">
                                                                    <div class="p-2 px-3 text-uppercase">Product</div>
                                                                </th>
                                                                <th scope="col" class="bg-light">
                                                                    <div class="py-2 text-uppercase">Price</div>
                                                                </th>
                                                                <th scope="col" class="bg-light">
                                                                    <div class="py-2 text-uppercase">Quantity</div>
                                                                </th>
                                                                <th scope="col" class="bg-light">
                                                                    <div class="py-2 text-uppercase">Details</div>
                                                                </th>
                                                                <th scope="col" class="bg-light">
                                                                    <div class="py-2 text-uppercase">Item Weight</div>
                                                                </th>
                                                                <th scope="col" class="bg-light">
                                                                    <div class="py-2 text-uppercase">Shipping Cost</div>
                                                                </th>
                                                                <th scope="col" class="bg-light">
                                                                    <div class="py-2 text-uppercase">Src Region Shipping Cost</div>
                                                                </th>
                                                                <th scope="col" class="bg-light">
                                                                    <div class="py-2 text-uppercase">Src Region Tax</div>
                                                                </th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                            <th scope="row" class=">
                                                                <div class="p-2">
                                                                    <div class="media align-items-center">
                                                                        <div class="thumb-sect mr-3 rounded shadow-sm">
                                                                            <img src="images/product-3.jpg" class="h-100 w-100 obj-cover" alt="...">
                                                                        </div>
                                                                        <div class="media-body">
                                                                            <h6 class="mt-0 mb-0 text-dark">Pepperidge Farm® Mint Chocolate Cookies</h6>
                                                                            <span class="text-muted">Shipped from UK.</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </th>
                                                                <td class="align-middle"><strong>$79.00</strong></td>
                                                                <td class="align-middle"><strong>3</strong></td>
                                                                <td class="align-middle"><strong>3</strong></td>
                                                                <td class="align-middle"><strong>3</strong></td>
                                                                <td class="align-middle"><strong>3</strong></td>
                                                                <td class="align-middle"><strong>3</strong></td>
                                                                <td class="align-middle"><strong>3</strong></td>
                                                            </tr>
                                                            <tr>
                                                            <th scope="row">
                                                                <div class="p-2">
                                                                    <div class="media align-items-center">
                                                                        <div class="thumb-sect mr-3 rounded shadow-sm">
                                                                            <img src="images/product-1.jpg" class="h-100 w-100 obj-cover" alt="...">
                                                                        </div>
                                                                        <div class="media-body">
                                                                            <h6 class="mt-0 mb-0 text-dark">Oreo Thins Chocolate Sandwich Cookies, Original Flavor, 1 Resealable Pack</h6>
                                                                            <span class="text-muted">Shipped from Uk</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </th>
                                                            <td class="align-middle"><strong>$79.00</strong></td>
                                                            <td class="align-middle"><strong>3</strong></td>
                                                            <td class="align-middle"><strong>3</strong></td>
                                                            <td class="align-middle"><strong>3</strong></td>
                                                            <td class="align-middle"><strong>3</strong></td>
                                                            <td class="align-middle"><strong>3</strong></td>
                                                            <td class="align-middle"><strong>3</strong></td>
                                                            </tr>
                                                            <tr>
                                                            <th scope="row">
                                                                <div class="p-2">
                                                                    <div class="media align-items-center">
                                                                        <div class="thumb-sect mr-3 rounded shadow-sm">
                                                                            <img src="images/product-2.jpg" class="h-100 w-100 obj-cover" alt="...">
                                                                        </div>
                                                                        <div class="media-body">
                                                                            <h6 class="mt-0 mb-0 text-dark">Oreo Golden Sandwich Cookies, Vanilla Flavor, 1 Resealable Family Size Pack</h6>
                                                                            <span class="text-muted">Shipped from UK</span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <td class="align-middle"><strong>$79.00</strong></td>
                                                                <td class="align-middle"><strong>3</strong></td>
                                                                <td class="align-middle"><strong>3</strong></td>
                                                                <td class="align-middle"><strong>3</strong></td>
                                                                <td class="align-middle"><strong>3</strong></td>
                                                                <td class="align-middle"><strong>3</strong></td>
                                                                <td class="align-middle"><strong>3</strong></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <!-- End -->
                                                <div class="form-row">
                                                    <div class="form-group col-lg-6 mb-3">
                                                        <button type="button" class="btn btn-info btn-block collapsed text-white" data-toggle="collapse" data-parent="#accordionCheckout" data-target="#collapseFive">Previous</button>
                                                    </div>
                                                </div>

                                                <div class="summary-info">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <div class="mb-3">
                                                                <h6 class="make-bold">Billing Information</h6>
                                                                <span id="p_billaddr">Not Selected</span>
                                                                <h6 class="make-bold">Shipping Information</h6>
                                                                <span id="p_shipaddr">Not Selected</span>
                                                                <h6 class="make-bold">Total Source Region Tax</h6>
                                                                <span id="p_srcRegionTax">0.00</span>
                                                                <h6 class="make-bold">Shipping Cost</h6>
                                                                <span id="onlyShipping">Not Selected</span>
                                                                <h6 class="make-bold">Other Charges</h6>
                                                                <span id="othercharges">Not Selected</span>
                                                                <h6 class="make-bold">Total for shipping and other charges</h6>
                                                                <span id="p_shipmethod">Not Selected</span>
                                                                <h6 class="make-bold">Payment Method</h6>
                                                                <span id="p_paymethod">Bank Transfer</span>
                                                            </div>
                                                            <div class="form-group form-check">
                                                                <input type="checkbox" class="form-check-input" id="acceptCheck1">
                                                                <label class="form-check-label" for="acceptCheck1">I have read and accept the <a href="">Terms and Conditions</a></label>
                                                            </div>
                                                            <div class="form-row">
                                                                <div class="form-group col-lg-6 mb-3">
                                                                    <button type="button" class="btn btn-main btn-block collapsed text-white">Place Order</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <div class="product-show">
                                <h6 class="make-bold">Best Selling Products in Target UK</h6>
                                <div class="row">
                                    <div class="col-lg-6 col-6 mb-3">
                                        <a href="" class="rmv-decoration">
                                            <div class="card text-dark h-100 thumbnail-card border-0">
                                                <div class="thumbnail-holder-3">
                                                    <img src="images/product-1.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                                </div>
                                                <div class="card-body d-flex flex-column align-items-start">
                                                    <h6 class="card-title make-bold flex-grow-1">N5,000</h6>
                                                    <p class="card-text text-muted item-name">Oreo Mini Chocolate Sandwich Cookies, Original Flavor, 1 Resealable Snak-Sak</p>
                                                    <badge class="badge badge-info">Shipped From Uk</badge>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-6 col-6 mb-3">
                                        <a href="" class="rmv-decoration">
                                            <div class="card text-dark h-100 thumbnail-card border-0">
                                                <div class="thumbnail-holder-3">
                                                    <img src="images/product-2.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                                </div>
                                                <div class="card-body d-flex flex-column align-items-start">
                                                    <h6 class="card-title make-bold flex-grow-1">N10,000</h6>
                                                    <p class="card-text text-muted item-name">Lenny & Larry's Lenny & Larry's The Complete Cookie®, Chocolate Chip, 4oz - Plant Based Protein Cookies, Vegan and Non-GMO</p>
                                                    <badge class="badge badge-info">Shipped From Uk</badge>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-6 col-6 mb-3">
                                        <a href="" class="rmv-decoration">
                                            <div class="card text-dark h-100 thumbnail-card border-0">
                                                <div class="thumbnail-holder-3">
                                                    <img src="images/product-3.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                                </div>
                                                <div class="card-body d-flex flex-column align-items-start">
                                                    <h6 class="card-title make-bold flex-grow-1">N20,000</h6>
                                                    <p class="card-text text-muted item-name">Chips Ahoy! Mini Chocolate Chip Cookies - Go Pak</p>
                                                    <badge class="badge badge-info">Shipped From Uk</badge>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-6 col-6 mb-3">
                                        <a href="" class="rmv-decoration">
                                            <div class="card text-dark h-100 thumbnail-card border-0">
                                                <div class="thumbnail-holder-3">
                                                    <img src="images/product-4.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                                </div>
                                                <div class="card-body d-flex flex-column align-items-start">
                                                    <h6 class="card-title make-bold flex-grow-1">N 30,000</h6>
                                                    <p class="card-text text-muted item-name">Rice Krispies Treats Crispy Marshmallow Squares Original with M&M'S Minis</p>
                                                    <badge class="badge badge-info">Shipped From Uk</badge>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addressModalCenter" tabindex="-1" role="dialog" aria-labelledby="addressModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addressModalCenterTitle">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                ...
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
            </div>
        </div>
    </div>
    <?php include "components/footer.inc.php"; ?>
    <?php include "components/javascript.inc.php"; ?>
  </body>
</html>
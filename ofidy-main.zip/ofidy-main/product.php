<?php include "components/head.inc.php"; ?>
  </head>
  <body>
    <?php include "components/navbar.inc.php"; ?>

    <div class="main-content">
       <div class="product-sect py-5">
            <div class="container-fluid">
                <div class="row mb-3">
                    <div class="col-lg-4">
                        <div class="thumbnail-holder-4">
                            <img src="images/product-1.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div class="product_description">
                            <h4 class="make-bold">Oreo Mini Chocolate Sandwich Cookies, Original Flavor, 1 Resealable Snak-Sak</h4>
                            <p class="mb-1">Product Code: 5069876</p>
                            <p>Store: Walmart</p>
                            <hr/>
                            <h4 class="make-bold">&#x20A6; 10,000</h4>
                            <hr/>
                            <form action="cart.php" method="post">
                                <div class="form-row align-items-center">
                                    <div class="form-group col-lg-3">
                                        <h5>Quantity</h5>
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <input type="number" class="form-control" value="1" />
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <button class="btn btn-main btn-block text-white">Add to cart</button>
                                    </div>
                                </div>
                            </form>
                            <hr/>
                            <div class="product-desc">
                                <h5 class="make-bold">Product Description</h5>
                                <hr/>
                                <p><small>QFX's portable party speaker has you covered for any occasion. This versatile PA speaker rolls on into events to pump out music or amplify announcements. Once it's in place, it can stream music from a variety of sources: wirelessly via Bluetooth-enabled devices, through USB and microSD card slots, or connected with a cable through the aux-in port. No matter what you're playing, the speaker's 8" woofer and amplifier ensure that everyone can hear clearly. The rechargeable battery lasts for 4-hours so you can stream music even in places without an outlet nearby.</small></p>

                                <p><small>4,400 Watts peak powers ensure everyone can be heardConnect your music device via Bluetooth to enjoy wireless controlPlay your MP3 music collection with a USB drive or microSD card and control with our remote controlListen to your favorite FM Radio station for the hottest playlistEnjoy 4-hours of continuous music with our built-in Li-ion batteryAdjust the bass and treble to fit the perfect moodPlug-in the microphone and adjust the volume or echo for that special someoneTurn on the LED Lights and let the lights move with the beat.</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="notice">
                            <h6 class="make-bold">General Delivery and Cancellation Notes</h6>
                            <hr/>
                            <div class="d-flex justify-content-between align-items-start mb-3"><i class="fa fa-circle text-info mr-3"></i> <span>2-7 days if product is delivered by a seller from the same country as the buyer</span></div>
                            <div class="d-flex justify-content-between align-items-start mb-3"><i class="fa fa-circle text-info mr-3"></i> <span>10-24 days if the product is delivered by a seller in a different country from the buyer</span></div>
                            <div class="d-flex justify-content-between align-items-start"><i class="fa fa-circle text-info mr-3"></i> <span>No cancellation of international orders - Returns allowed only for defective and wrong items - Warranty is as specified by the seller or manufacturer</span></div>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                     <div class="col-lg-12">
                        <div class="similiar-sect">
                            <h4 class="make-bold">Similar Items You May Like</h4>
                            <div class="row">
                                <div class="col-lg-2 col-6 mb-3">
                                    <a href="" class="rmv-decoration">
                                        <div class="card text-dark h-100 thumbnail-card border-0">
                                            <div class="thumbnail-holder-3">
                                                <img src="images/product-1.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                            </div>
                                            <div class="card-body d-flex flex-column align-items-start">
                                                <h6 class="card-title make-bold flex-grow-1">N5,000</h6>
                                                <p class="card-text text-muted item-name">Oreo Mini Chocolate Sandwich Cookies, Original Flavor, 1 Resealable Snak-Sak</p>
                                                <badge class="badge badge-info">Shipped From Uk</badge>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-6 mb-3">
                                    <a href="" class="rmv-decoration">
                                        <div class="card text-dark h-100 thumbnail-card border-0">
                                            <div class="thumbnail-holder-3">
                                                <img src="images/product-2.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                            </div>
                                            <div class="card-body d-flex flex-column align-items-start">
                                                <h6 class="card-title make-bold flex-grow-1">N10,000</h6>
                                                <p class="card-text text-muted item-name">Lenny & Larry's Lenny & Larry's The Complete Cookie®, Chocolate Chip, 4oz - Plant Based Protein Cookies, Vegan and Non-GMO</p>
                                                <badge class="badge badge-info">Shipped From Uk</badge>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-6 mb-3">
                                    <a href="" class="rmv-decoration">
                                        <div class="card text-dark h-100 thumbnail-card border-0">
                                            <div class="thumbnail-holder-3">
                                                <img src="images/product-3.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                            </div>
                                            <div class="card-body d-flex flex-column align-items-start">
                                                <h6 class="card-title make-bold flex-grow-1">N20,000</h6>
                                                <p class="card-text text-muted item-name">Chips Ahoy! Mini Chocolate Chip Cookies - Go Pak</p>
                                                <badge class="badge badge-info">Shipped From Uk</badge>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-6 mb-3">
                                    <a href="" class="rmv-decoration">
                                        <div class="card text-dark h-100 thumbnail-card border-0">
                                            <div class="thumbnail-holder-3">
                                                <img src="images/product-4.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                            </div>
                                            <div class="card-body d-flex flex-column align-items-start">
                                                <h6 class="card-title make-bold flex-grow-1">N 30,000</h6>
                                                <p class="card-text text-muted item-name">Rice Krispies Treats Crispy Marshmallow Squares Original with M&M'S Minis</p>
                                                <badge class="badge badge-info">Shipped From Uk</badge>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-6 mb-3">
                                    <a href="" class="rmv-decoration">
                                        <div class="card text-dark h-100 thumbnail-card border-0">
                                            <div class="thumbnail-holder-3">
                                                <img src="images/product-5.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                            </div>
                                            <div class="card-body d-flex flex-column align-items-start">
                                                <h6 class="card-title make-bold flex-grow-1">N40,000</h6>
                                                <p class="card-text text-muted item-name">BelVita Breakfast Biscuits, Blueberry Flavor</p>
                                                <badge class="badge badge-info">Shipped From Uk</badge>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-6 mb-3">
                                    <a href="" class="rmv-decoration">
                                        <div class="card text-dark h-100 thumbnail-card border-0">
                                            <div class="thumbnail-holder-3">
                                                <img src="images/product-6.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                            </div>
                                            <div class="card-body d-flex flex-column align-items-start">
                                                <h6 class="card-title make-bold flex-grow-1">N4,000</h6>
                                                <p class="card-text text-muted item-name">Pepperidge Farm® Mint Chocolate Cookies</p>
                                                <badge class="badge badge-info">Shipped From Uk</badge>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-6 mb-3">
                                    <a href="" class="rmv-decoration">
                                        <div class="card text-dark h-100 thumbnail-card border-0">
                                            <div class="thumbnail-holder-3">
                                                <img src="images/product-1.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                            </div>
                                            <div class="card-body d-flex flex-column align-items-start">
                                                <h6 class="card-title make-bold flex-grow-1">N5,000</h6>
                                                <p class="card-text text-muted item-name">Oreo Mini Chocolate Sandwich Cookies, Original Flavor, 1 Resealable Snak-Sak</p>
                                                <badge class="badge badge-info">Shipped From Uk</badge>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-6 mb-3">
                                    <a href="" class="rmv-decoration">
                                        <div class="card text-dark h-100 thumbnail-card border-0">
                                            <div class="thumbnail-holder-3">
                                                <img src="images/product-2.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                            </div>
                                            <div class="card-body d-flex flex-column align-items-start">
                                                <h6 class="card-title make-bold flex-grow-1">N10,000</h6>
                                                <p class="card-text text-muted item-name">Lenny & Larry's Lenny & Larry's The Complete Cookie®, Chocolate Chip, 4oz - Plant Based Protein Cookies, Vegan and Non-GMO</p>
                                                <badge class="badge badge-info">Shipped From Uk</badge>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-6 mb-3">
                                    <a href="" class="rmv-decoration">
                                        <div class="card text-dark h-100 thumbnail-card border-0">
                                            <div class="thumbnail-holder-3">
                                                <img src="images/product-3.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                            </div>
                                            <div class="card-body d-flex flex-column align-items-start">
                                                <h6 class="card-title make-bold flex-grow-1">N20,000</h6>
                                                <p class="card-text text-muted item-name">Chips Ahoy! Mini Chocolate Chip Cookies - Go Pak</p>
                                                <badge class="badge badge-info">Shipped From Uk</badge>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-6 mb-3">
                                    <a href="" class="rmv-decoration">
                                        <div class="card text-dark h-100 thumbnail-card border-0">
                                            <div class="thumbnail-holder-3">
                                                <img src="images/product-4.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                            </div>
                                            <div class="card-body d-flex flex-column align-items-start">
                                                <h6 class="card-title make-bold flex-grow-1">N 30,000</h6>
                                                <p class="card-text text-muted item-name">Rice Krispies Treats Crispy Marshmallow Squares Original with M&M'S Minis</p>
                                                <badge class="badge badge-info">Shipped From Uk</badge>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-6 mb-3">
                                    <a href="" class="rmv-decoration">
                                        <div class="card text-dark h-100 thumbnail-card border-0">
                                            <div class="thumbnail-holder-3">
                                                <img src="images/product-5.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                            </div>
                                            <div class="card-body d-flex flex-column align-items-start">
                                                <h6 class="card-title make-bold flex-grow-1">N40,000</h6>
                                                <p class="card-text text-muted item-name">BelVita Breakfast Biscuits, Blueberry Flavor</p>
                                                <badge class="badge badge-info">Shipped From Uk</badge>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-6 mb-3">
                                    <a href="" class="rmv-decoration">
                                        <div class="card text-dark h-100 thumbnail-card border-0">
                                            <div class="thumbnail-holder-3">
                                                <img src="images/product-6.jpg" class="card-img-top obj-contain h-100 w-100" alt="...">
                                            </div>
                                            <div class="card-body d-flex flex-column align-items-start">
                                                <h6 class="card-title make-bold flex-grow-1">N4,000</h6>
                                                <p class="card-text text-muted item-name">Pepperidge Farm® Mint Chocolate Cookies</p>
                                                <badge class="badge badge-info">Shipped From Uk</badge>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
       </div>
    </div>
    <?php include "components/footer.inc.php"; ?>
    <?php include "components/javascript.inc.php"; ?>
  </body>
</html>
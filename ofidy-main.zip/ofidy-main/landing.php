<?php include "components/head.inc.php"; ?>
  </head>

  <body>

    <nav class="navbar navbar-light bg-white text-white fixed-top py-3">
        <div class="container-fluid">
            <div class="d-flex justify-content-end align-items-center w-100">
                <a class="btn btn-success btn-sm text-white make-bold text-uppercase lt-2" href="index.php">Log In</a>
            </div>
        </div>
    </nav>

    <div class="landing-view-sect py-50 use-image-2" style="background-image:url(images/landing-bg.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 pt-5 mx-auto">
                    <div class="card shadow">
                        <div class="card-body">
                            <p class="text-center"><img src="images/logo.png" class="img-fluid" width="200" /></p>
                            <!-- <h4 class="make-bold text-dark text-center">Shop anywhere in the world and have it delivered to you</h4> -->
                            <p class="text-dark text-center">Beyond local grocery shopping, you can shop non-perishables anywhere in the UK, USA, Canada and Nigeria and have the items delivered to you</p>
                            <form>
                                <div class="form-group">
                                    <label>Address or Zip Code</label>
                                    <input type="text" class="form-control" />
                                </div>
                                 <div class="form-group">
                                   <button class="btn btn-main text-white btn-block">Continue</button>
                                </div>
                            </form>
                            <p class="text-center">Already have an account? <a href="login.php" class="text-success">Log In</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

     <div class="features pt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <a href="products.php" class="rmv-decoration">
                        <div class="card border-rad-12 box-shadow items-card border-0 h-100">
                            <div class="card-body">
                                <div class="media align-items-center">
                                    <div class="thumb-sect mr-3">
                                        <img src="images/online-shopping.png" class="h-100 w-100 obj-cover" alt="...">
                                    </div>
                                    <div class="media-body">
                                        <h4 class="mt-0 make-bold mb-0 text-dark">500 million products</h4>
                                        <span class="text-muted">available to shop across the catalog.</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 mb-4">
                    <a href="products.php" class="rmv-decoration">
                        <div class="card border-rad-12 box-shadow items-card border-0 h-100">
                            <div class="card-body">
                                <div class="media align-items-center">
                                    <div class="thumb-sect mr-3">
                                        <img src="images/grocery.png" class="h-100 w-100 obj-cover" alt="...">
                                    </div>
                                    <div class="media-body">
                                        <h4 class="mt-0 make-bold mb-0 text-dark">40,000 stores</h4>
                                        <span class="text-muted">from local grocers to chain stores</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 mb-4">
                    <a href="products.php" class="rmv-decoration">
                        <div class="card border-rad-12 box-shadow items-card border-0 h-100">
                            <div class="card-body">
                                <div class="media align-items-center">
                                    <div class="thumb-sect mr-3">
                                        <img src="images/groceries.png" class="h-100 w-100 obj-cover" alt="...">
                                    </div>
                                    <div class="media-body">
                                        <h4 class="mt-0 make-bold mb-0 text-dark">6,000 cities</h4>
                                        <span class="text-muted">served across the US & canada</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <!-- <div class="col-lg-3 mb-4">
                    <a href="products.php" class="rmv-decoration">
                        <div class="card border-rad-12 box-shadow items-card border-0 h-100">
                            <div class="card-body">
                                <div class="media align-items-center">
                                    <div class="thumb-sect mr-3">
                                        <img src="images/brand-4.png" class="h-100 w-100 obj-cover" alt="...">
                                    </div>
                                    <div class="media-body">
                                        <h5 class="mt-0 make-bold mb-0 text-dark">Millions of orders</h5>
                                        <span class="text-muted">Delivered or picked yearly</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div> -->
            </div>
        </div>
    </div>

    <div class="info-list-sect py-50">
        <h2 class="text-center mb-5 text-muted">Global shopping you can count on</h2>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-3">
                    <a href="" class="rmv-decoration">
                        <div class="card h-100 thumbnail-card border-0">
                            <div class="thumbnail-holder-6">
                                <img src="images/img-1.jpg" class="card-img-top obj-cover h-100 w-100" alt="...">
                            </div>
                            <div class="card-body d-flex flex-column align-items-start">
                                <h3 class="card-title make-medium flex-grow-1 make-bold">Choose what you want</h3>
                                <p class="card-text">Select items from your favourite stores at ofidy.com or via the app.</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 mb-3">
                    <a href="" class="rmv-decoration">
                        <div class="card h-100 thumbnail-card border-0">
                            <div class="thumbnail-holder-6">
                                <img src="images/img-2.jpg" class="card-img-top obj-cover h-100 w-100" alt="...">
                            </div>
                            <div class="card-body d-flex flex-column align-items-start">
                                <h3 class="card-title make-bold flex-grow-1">See real-time updates</h3>
                                <p class="card-text">Personal shoppers pick items with care. Chat as they shop and manage your order.</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 mb-3">
                    <a href="" class="rmv-decoration">
                        <div class="card h-100 thumbnail-card border-0">
                            <div class="thumbnail-holder-6">
                                <img src="images/img-2.jpg" class="card-img-top obj-cover h-100 w-100" alt="...">
                            </div>
                            <div class="card-body d-flex flex-column align-items-start">
                                <h3 class="card-title make-bold flex-grow-1">100% Quality</h3>
                                <p class="card-text">Enjoy Ofidy's 100% guarantee on every order.</p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- <div class="inner-card-view py-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="thumbnail-holder-2 shadow bord-rad-50">
                        <img src="images/grocery-banner.jpg" class="card-img-top obj-cover h-100 w-100" alt="...">
                    </div>
                </div>
            </div>
        </div>
    </div> -->

    <?php include "components/footer.inc.php"; ?>
    <?php include "components/javascript.inc.php"; ?>
  </body>
</html>